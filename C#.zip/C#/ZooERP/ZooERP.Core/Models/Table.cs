namespace ZooERP.Core.Models
{
    public class Table : Thing { }
}