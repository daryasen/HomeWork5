namespace ZooERP.Core.Models
{
    public class Computer : Thing { }
}