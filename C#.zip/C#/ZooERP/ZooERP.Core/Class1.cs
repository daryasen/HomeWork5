﻿namespace ZooERP.Core;
public class Class1
{

}
