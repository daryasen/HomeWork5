namespace ZooERP.Core.Interfaces
{
    public interface IHealthCheckable
    {
        bool PerformHealthCheck();
    }
}