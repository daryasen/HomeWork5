using ZooERP.Core.Models;

namespace ZooERP.Core.Interfaces
{
    public interface IVeterinaryClinic
    {
        bool CheckAnimal(Animal animal);
    }
}